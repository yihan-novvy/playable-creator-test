System.register("chunks:///bullet.release.wasm-e702f478.js",[],(function(e){"use strict";return{execute:function(){e("default","assets/bullet.release.wasm-10f8cbd4.wasm")}}}));
