System.register("chunks:///meshopt_decoder.wasm-43855155.js",[],(function(e){"use strict";return{execute:function(){e("default","assets/meshopt_decoder.wasm-12c0a404.wasm")}}}));
